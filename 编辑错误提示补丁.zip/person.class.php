<?php
class	person	extends	control
{
	function __construct()
	{
		if(!isset($_SESSION['uid']))
		{
             header("Location:index.php?a=home&c=login&m=index");
			 exit();
		}
		parent::__construct();

	}
	
	function index()
	{
		if(isset($_SESSION['user']))
		{
			$this->assign('user',$_SESSION['user']);
		}
		else
		{
			$this->assign('user',"未登录");
		}
		$profile = '';
		$id = $_SESSION['uid'];
		$sql = "SELECT name, description,location,large_picture FROM user WHERE id='$id'" ;
		$mysqli = new mysqli(alpha::$config['host'], alpha::$config['user'] ,alpha::$config['password'], alpha::$config['dbname']);
		$mysqli->set_charset("utf8");		
		if ($result = $mysqli->query($sql)) {
			   while ($row = $result->fetch_assoc()) {
				   
				   if($row['large_picture'] =="")
				   {
					   $row['large_picture'] = 'home/common/img/profile_big.jpg';
				   }
				   if($row['location'] == '')
				   {
					   $row['location'] = '未设置';
				   }
				   if($row['description'] == '')
				   {
					   $row['description'] = '什么都没有说';
				   }
				   
				   $profile .='<div class="ibox ">
								<div class="ibox-title">
									<h5>个人信息</h5>
								</div>
							<div>
                            <div class="ibox-content no-padding border-left-right">
                                <img alt="image" class="img-fluid" src="'.$row['large_picture'].'">
                            </div>
                            <div class="ibox-content profile-content">
                                <h4><strong>'.$row['name'].'</strong></h4>
                                <p><i class="fa fa-map-marker"></i>'.$row['location'].'</p>
                                <h4>
                                    个人简介
                                </h4>
                                <p>
									'.$row['description'].'
								</p>                               
                                <div class="user-button">
                                    <div class="row">
                                        <div class="col-lg-6">
											<button type="button "  class="btn btn-primary" data-toggle="modal" data-target="#myModal6">
												<i class="fa fa-drupal"></i>
												修改资料
											</button>
										</div>
										<div class="modal inmodal fade" style="margin-top:100px" id="myModal6" tabindex="-1" role="dialog"  aria-hidden="true">
											<div class="modal-dialog modal-sm">
												<div class="modal-content">													
													<div class="modal-body">
														<div class="form-group">
															<label>修改资料</label> 
															<input style="margin-top:30px" type="text" id="edit_picture" placeholder="图片地址"  class="form-control">
															<input style="margin-top:30px" type="text" id="edit_location" placeholder="我的位置"  class="form-control">
														    <input style="margin-top:30px" type="text" id="edit_description" placeholder="个人简介"  class="form-control">																											
														</div>												
													</div>

													<div class="modal-footer">
														<button type="button" class="btn btn-white" data-dismiss="modal"> 取消</button>
														<button type="button" id="edit_user" class="btn btn-primary">确定</button>
													</div>
												</div>
											</div>
										</div>
										<div class="col-lg-6">
											<button type="button " class="btn btn-default" data-toggle="modal" data-target="#myModal7">
												<i class="fa fa-paper-plane-o"></i>
												发送消息
											</button>
										</div>
										<div class="modal inmodal fade" style="margin-top:100px" id="myModal7" tabindex="-1" role="dialog"  aria-hidden="true">
											<div class="modal-dialog modal-sm">
												<div class="modal-content">													
													<div class="modal-body">
														<div class="form-group">
															<label>发送消息</label> 
															<input style="margin-top:30px" type="text" id="to_user_name" placeholder="发送给"  class="form-control">
														    <input style="margin-top:30px" type="text" id="content" placeholder="发送内容"  class="form-control">																											
														</div>												
													</div>

													<div class="modal-footer">
														<button type="button" class="btn btn-white" data-dismiss="modal"> 取消</button>
														<button type="button" id="send_message" class="btn btn-primary">确定</button>
													</div>
												</div>
											</div>
										</div>
                                    </div>
                                </div>
                            </div>
							</div>
							</div>';
			   }
			   $result->close();
		}
		if($profile == '')
		{
			$profile = '<div class="ibox ">
                        <div class="ibox-title">
                            <h5>个人信息</h5>
                        </div>
                        <div>
                            <div class="ibox-content no-padding border-left-right">
                                <img alt="image" class="img-fluid" src="home/common/img/profile_big.jpg">
                            </div>
                            <div class="ibox-content profile-content">
                                <h4><strong>错误</strong></h4>
                                <p><i class="fa fa-map-marker"></i>未设置</p>
                                <h4>
                                    个人简介
                                </h4>
                                <p>
								进入了错误的个人信息页面
								</p>                               
                                <div class="user-button">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <button type="button" class="btn btn-primary btn-sm btn-block"><i class="fa fa-envelope"></i>发送信息</button>
                                        </div>
                                        <div class="col-md-6">
                                            <button type="button" class="btn btn-default btn-sm btn-block"><i class="fa fa-coffee"></i> 修改资料</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>';
		}
		
		$page_size = isset($_POST['rows'])?$_POST['rows'] : 10;
		$page = isset($_POST['page'])?$_POST['page'] : 1;
		$sql ="";
		if(isset($_SESSION['uid']) && ($_SESSION['uid']!=""))
		{
			$category = "id IN (SELECT document_id FROM  category_and_document) AND ";		
			$sql .= $category;
		}
		if(isset($_SESSION['uid']) && ($_SESSION['uid']!=""))
		{
			$category = "user_id ='". $_SESSION['uid'] ."' AND ";
			$sql .= $category;
		}
		if (!empty($sql)) {
			$sql = 'WHERE '.substr($sql, 0, -4);
		}
		$first = $page_size * ($page - 1);
		$is_data ="";
		$data = '<div id="tbody" style="padding-left:50px">';
		$mysqli = new mysqli(alpha::$config['host'], alpha::$config['user'] ,alpha::$config['password'], alpha::$config['dbname']);
		$mysqli->set_charset("utf8");
		$mysql = "SELECT id,title,description FROM document $sql LIMIT $first,$page_size";
		if ($result = $mysqli->query($mysql)) {
			   while ($row = $result->fetch_assoc()) {
				   $id = $row['id'];				   
				   $category = "";
				   $mysql = "SELECT name FROM  category WHERE id IN (SELECT category_id  FROM  category_and_document WHERE document_id='$id')";
					if ($results = $mysqli->query($mysql)) {
						while ($rows = $results->fetch_assoc()) {
							$category = $category . $rows['name'] . "，";
						}
						$results->close();						
					}
				   if($category == "")
				   {					
						$category = "未分类";
				   }
				   else
				   {
					   $category  = substr($category, 0, -3);
				   }
				   $is_data .="a";
				   $data .= '<div class="hr-line-dashed"></div>
                            <div class="search-result">
                                <h3><a href="index.php?a=home&c=home&m=content&id='. $row['id']  .'">' . $row['title'] .'</a></h3>
                                <p style="font-size:13px">'. $category .'</p>
                                <p style="font-size:15px">'. $row['description'] .'</p></div>';	
			   }
			   $result->close();
		}
		$data .='</div>';
		if($is_data == "")
		{
			 $data = ' 	<div  id = "tbody" style="padding-left:50px">
						<div class="hr-line-dashed"></div>
                            <div class="search-result">
                                <h3><a href="#"><a href="#">暂无词条</a></h3>
                                <p style="font-size:13px">未分类</p>
                                <p style="font-size:15px">此词条暂未编辑，敬请期待</p></div></div>';
		}
		$document_number = 0;
		$mysql = "SELECT id FROM document $sql";
		if ($result = $mysqli->query($mysql))
		{
			$document_number = $result->num_rows;
        }
		$page_number = ceil($document_number/$page_size);
		
		if($page_number == 0)
		{
			$page_number = 1;
		}
		$data.='<div class="col-lg-9 animated fadeInRight">	
				<div class="hr-line-dashed"></div>
				<div class="text-center" style="margin-left:200px">
					<div class="btn-group">									
						<button class="btn btn-primary" id = "total" type="button">'.$page_number  .'页</button>
						<button type="button" id="previous" class="btn btn-white"><i class="fa fa-chevron-left"></i></button>
						<button id="present_page" class="btn btn-white">'.$page.'</button>
						<button type="button" id= "next" class="btn btn-white"><i class="fa fa-chevron-right"></i> </button>
						<input type="text" id="go_input" class="form-control form-control-sm" style="width:60px" placeholder="前往">
						<button class="btn btn-primary" id="go_page" type="button">GO</button>
				</div></div></div>';
		
		
		
		$this->assign('profile',$profile);
		$this->assign('data',$data);
		$this->display('profile');
	}
	
	function person_json()
	{
		$page_size = isset($_POST['rows'])?$_POST['rows'] : 10;
		$page = isset($_POST['page'])?$_POST['page'] : 1;
		$sql ="";
		if(isset($_SESSION['uid']) && ($_SESSION['uid']!=""))
		{
			$category = "user_id ='". $_SESSION['uid'] ."' AND ";
			$sql .= $category;
		}
		if(isset($_SESSION['uid']) && ($_SESSION['uid']!=""))
		{
			$category = "id IN (SELECT document_id FROM  category_and_document) AND ";
			$sql .= $category;
		}
		if (!empty($sql)) {
			$sql = 'WHERE '.substr($sql, 0, -4);
		}
		$first = $page_size * ($page - 1);
		$data =array();
		$data['tbody'] ='';
		$mysqli = new mysqli(alpha::$config['host'], alpha::$config['user'] ,alpha::$config['password'], alpha::$config['dbname']);
		$mysqli->set_charset("utf8");
		$mysql = "SELECT id,title,description FROM document $sql LIMIT $first,$page_size";
		if ($result = $mysqli->query($mysql)) {
			   while ($row = $result->fetch_assoc()) {
				   $id = $row['id'];				   
				   $category = "";
				   $mysql = "SELECT name FROM  category WHERE id IN (SELECT category_id  FROM  category_and_document WHERE document_id='$id')";
					if ($results = $mysqli->query($mysql)) {
						while ($rows = $results->fetch_assoc()) {
							$category = $category . $rows['name'] . "，";
						}
						$results->close();						
					}
				   if($category == "")
				   {					
						$category = "未分类";
				   }
				   else
				   {
					   $category  = substr($category, 0, -3);
				   }
				   $data['tbody'] .= '<div class="hr-line-dashed"></div>
								<div class="search-result">
                                <h3><a href="index.php?a=home&c=home&m=content&id='. $row['id']  .'">' . $row['title'] .'</a></h3>
                                <p style="font-size:13px">'. $category .'</p>
                                <p style="font-size:15px">'. $row['description'] .'</p></div>';	
			   }
			   $result->close();
		}
		if($data['tbody'] == "")
		{
			 $data['tbody']= '<div class="hr-line-dashed"></div>
                            <div class="search-result">
                                <h3><a href="#"><a href="#">暂无词条</a></h3>
                                <p style="font-size:13px">未分类</p>
                                <p style="font-size:15px">此词条暂未编辑，敬请期待</p></div>';
		}
		$document_number = 0;
		$mysql = "SELECT id FROM document $sql";
		if ($result = $mysqli->query($mysql))
		{
			$document_number = $result->num_rows;
        }
		$page_number = ceil($document_number/$page_size);
		
		if($page_number == 0)
		{
			$page_number = 1;
		}
		$data['total'] = $page_number;
		$data['page'] = $page;	
		echo json_encode($data);
	}
	
	
	
	function edit_user()
	{
		$id = $_SESSION['uid'];
		$large_picture = $_POST['large_picture'];
		$location = $_POST['location'];
		$description = $_POST['description'];
		$mysqli = new mysqli(alpha::$config['host'], alpha::$config['user'] ,alpha::$config['password'], alpha::$config['dbname']);
		$mysqli->set_charset("utf8");
		$sql = "UPDATE user SET large_picture='$large_picture',location = '$location',description='$description' WHERE id='$id'";
		if($mysqli->query($sql))
		{
			echo 1;
		}
		else
		{
			echo 0;
		}
	}
	
	function edit()
	{
		$id = isset($_GET['id'])?$_GET['id'] : 0;
		if(isset($_SESSION['user']))
		{
			$this->assign('user',$_SESSION['user']);
		}
		else
		{
			$this->assign('user',"未登录");
		}
		$this->assign('id',$id);
		$this->display("edit");
	}
	
	function edit_json()
	{
		$id = $_POST['id'];
		$mysqli = new mysqli(alpha::$config['host'], alpha::$config['user'] ,alpha::$config['password'], alpha::$config['dbname']);
		$mysqli->set_charset("utf8");
		$data = array();
		$sql = "SELECT  title,description,catalog,content  FROM  document WHERE id='$id'";	
		if ($result = $mysqli->query($sql)) {
			   while ($row = $result->fetch_assoc()) {
				   $data['title'] = $row['title'];
				   $data['description'] = $row['description'];
				   $data['category'] = array();
				   $mysql = "SELECT name FROM  category WHERE id IN (SELECT category_id  FROM  category_and_document WHERE document_id='$id')";
					if ($results = $mysqli->query($mysql)) {
						while ($rows = $results->fetch_assoc()) {
							$data['category'][] = $rows['name'] ;
						}
						$results->close();						
					}
				   if(empty($data['category']))
				   {					
						$data['category'][] = '未分类';
				   }
				   $data['catalog'] = array();
				   $data['catalog'] = explode("/",$row['catalog']);
				   $row['content'] = str_replace(array("\r\n", "\t","\r", "\n"), "", $row['content']);
				   $data['content'] = array();
				   $data['content'] = explode("#####",$row['content']);
			   }
			    $result->close();
		}
		if(empty($data))
		{
			$data['title'] = "错误";
			$data['description'] = '编辑了错误的词条';
			$data['category'][] = '未分类';
			$data['catalog'][] = '错误';
			$data['content'][] = '编辑了错误的词条';
		}
			
		echo json_encode($data);
	}
	
	function edit_insert()
	{
		$id = $_POST['id'];
		
		$user_id = $_SESSION['uid'];
		
		$date = time();
		
		$document_id = 0;
		$exist = 0;
		$mysqli = new mysqli(alpha::$config['host'], alpha::$config['user'] ,alpha::$config['password'], alpha::$config['dbname']);
		$mysqli->set_charset("utf8");
		$sql = "SELECT id FROM document WHERE id='$id'";
		if($results = $mysqli->query($sql))
		{
			while ($rows = $results->fetch_assoc()) {
				$exist = $results->num_rows;
			}
		}
		if($exist == 0)
		{
			$sql ="SELECT id FROM document order by id desc limit 0,1";
			if($results = $mysqli->query($sql))
			{
				while ($rows = $results->fetch_assoc()) {
					$document_id = $rows['id'] + 1;
				}
				$results->close();
			}
			$sql ="SELECT document_id FROM verify";
			if($results = $mysqli->query($sql))
			{
				while ($rows = $results->fetch_assoc()) {
					if($document_id < $rows['document_id'])
					{
						$document_id = $rows['document_id'];
					}
				}
				$results->close();
				$document_id = $document_id + 1;
			}
			
		}
		else
		{
			$document_id = $id;
		}
	
		$title =$_POST['title'];
		if($title == "")
		{
			echo  2;
			exit;
		}
		$description = $_POST['content'][0];
		if($description == "")
		{
			echo  3;
			exit;
		}
		
		if(!empty($_POST['category']))
		{	
			for($i = 0;$i < count($_POST['category']) ;$i++)
			{
				$name = $_POST['category'][$i];
				$sql = "SELECT id  FROM category  WHERE name='$name'";
				$result = $mysqli->query($sql);	
				$row= $result->fetch_assoc(); 
				$count = $result->num_rows;
				if($count == 0)
				{
					echo 4;
					exit;
				}
					
			}
		}
		else
		{
			echo 5;
			exit;
		}				
		if(empty($_POST['catalog']))
		{
			echo 6;
			exit;
		}
		else
		{
			$catalog ="";
			for($i = 0;$i < count($_POST['catalog']) ;$i++)
			{
				$catalog .= $_POST['catalog'][$i] ."/";
			}
			$catalog  = substr($catalog, 0, -1);		
		}
			
		if(isset($_POST['content'][1]))
		{
			$content = '';
			for($i = 1;$i < count($_POST['content']) ;$i++)
			{
				$content .=  $_POST['content'][$i] .'#####';
			}
			$content  = substr($content, 0, -5);	
		}
		$sql = "INSERT INTO verify (document_id, user_id, state,title , description , catalog , content , date) VALUES ('$document_id','$user_id','未审核','$title','$description' , '$catalog' , '$content' , '$date')";
		if($mysqli->query($sql))
		{
			echo 1;
		}
		else
		{
			echo 7;
			exit;
		}
		$_POST['category'] = array_values(array_unique ($_POST['category']));
		if(!empty($_POST['category']))
		{	
			for($i = 0;$i < count($_POST['category']) ;$i++)
			{
				$name = $_POST['category'][$i];
				$sql = "SELECT id  FROM category  WHERE name='$name'";
				$result = $mysqli->query($sql);	
				$row= $result->fetch_assoc(); 
				$count = $result->num_rows;
				if($count)
				{
					$category_id = $row['id'];
					$sql = "SELECT id  FROM verify  WHERE document_id='$document_id' order by id desc limit 0,1";
					$result = $mysqli->query($sql);	
					$row = $result->fetch_assoc(); 
					$verify_id = $row['id'];
					$sql = "INSERT INTO category_and_verify (category_id,document_id,verify_id, date) VALUES ('$category_id','$document_id','$verify_id','$date')";		
					$mysqli->query($sql);
				}
			}	 
		}
	}
	
	function read_message()
	{
		$id = $_SESSION['uid'];
		$page_size = isset($_POST['rows'])?$_POST['rows'] : 10;
		$page = isset($_POST['page'])?$_POST['page'] : 1;
		$sql ="";
		if (isset($_POST['clear']) && !empty($_POST['clear'])) {
			unset($_SESSION['mstate']);
		}
		if(isset($_POST['state']) &&($_POST['state'] !=""))
		{
			$_SESSION['mstate'] = $_POST['state'];
		}
		if(isset($_SESSION['mstate']) && ($_SESSION['mstate']!=""))
		{
			$state = "state = '" . $_SESSION['mstate']."' AND ";
			$sql .= $state;
		}
		if(isset($_SESSION['uid']) && ($_SESSION['uid']!=""))
		{
			$category = "to_user_id ='". $_SESSION['uid'] ."' AND ";
			$sql .= $category;
		}
		if (!empty($sql)) {
			$sql = 'WHERE '.substr($sql, 0, -4);
		}
		$first = $page_size * ($page - 1);
		$data =array();
		$data['mbody'] ='';
		$mysqli = new mysqli(alpha::$config['host'], alpha::$config['user'] ,alpha::$config['password'], alpha::$config['dbname']);
		$mysqli->set_charset("utf8");
		$mysql = "SELECT id,user_name,state,content,date FROM message $sql LIMIT $first,$page_size";
		if ($result = $mysqli->query($mysql)) {
			   while ($row = $result->fetch_assoc()) {
				   $date = date("Y-m-d H:i:s",$row["date"]);
				   $data['mbody'] .= '<div class="hr-line-dashed"></div>
								<div class="search-result">
                                <h3><a class="read_message" id="'. $row['id'] .'">' . $row['user_name'] .'</a></h3>
                                <p id="state'. $row['id'] .'" style="font-size:13px">'. $row['state'] .'/'. $date  .'</p>
                                <p style="font-size:15px">'. $row['content'] .'</p></div>';	
			   }
			   $result->close();
		}
		if($data['mbody'] == "")
		{
			 $data['mbody']= '<div class="hr-line-dashed"></div>
                            <div class="search-result">
                                <h3><a href="#"><a href="#">没有消息</a></h3>
                                <p style="font-size:13px">已读</p>
                                <p style="font-size:15px">还没有消息人发送消息给你</p></div>';
		}
		$document_number = 0;
		$mysql = "SELECT id FROM message $sql";
		if ($result = $mysqli->query($mysql))
		{
			$document_number = $result->num_rows;
        }
		$page_number = ceil($document_number/$page_size);
		
		if($page_number == 0)
		{
			$page_number = 1;
		}
		$data['mtotal'] = $page_number;
		$data['mpage'] = $page;
		echo json_encode($data);
	}
	
	function save_message()
	{
		$user_id = $_SESSION['uid'];
		$user_name = $_SESSION['user'] ;
		$to_user_name = $_POST['to_user_name'];
		$to_user_id = 0;
		$mysqli = new mysqli(alpha::$config['host'], alpha::$config['user'] ,alpha::$config['password'], alpha::$config['dbname']);		
		$mysqli->set_charset("utf8");
		$sql = "SELECT  id  FROM  user WHERE name='$to_user_name'";
		if ($result = $mysqli->query($sql)) {
			while ($row = $result->fetch_assoc()) {
			 $to_user_id = $row['id'];
			}
			$result->close();					
		  }
		if($to_user_id == 0 ||$to_user_name == $user_name)
		{
			echo 0;
			exit;
		}
		$content = $_POST['content'];
		if($content =="")
		{
			echo 0;
			exit;
		}
		$date = time();
		$sql = "INSERT INTO message (user_id,user_name,to_user_id,to_user_name,state,content,date) VALUES ('$user_id','$user_name','$to_user_id','$to_user_name','未读','$content','$date')";		
		if($mysqli->query($sql))
		{
			echo 1;
		}
		else
		{
			echo 0;
		}
		
	}
	
	function change_message()
	{
		$id = $_POST['id'];
		if($id !=0 || $id !="")
		{
			$sql = "UPDATE message SET state='已读' WHERE id='$id'";
			$mysqli = new mysqli(alpha::$config['host'], alpha::$config['user'] ,alpha::$config['password'], alpha::$config['dbname']);		
			$mysqli->set_charset("utf8");
			if($mysqli->query($sql))
			{
				$sql = "SELECT  user_name,state,content,date  FROM message WHERE id='$id'";
				if ($result = $mysqli->query($sql)) {
					while ($row = $result->fetch_assoc()) {
						$row['date'] = date("Y-m-d H:i:s",$row["date"]);
						echo json_encode($row);
					}
					$result->close();
				}
				else
				{
					echo 0;
				}
			}
			else
			{
				echo 0;
			}
		}
		else
		{
			echo 0;
		}
	}
	
	
}
?>