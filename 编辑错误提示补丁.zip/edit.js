$(document).ready(function () {
	$('#input_category').keyup(function(event){
	  if(event.keyCode ==13){
		var x = 1000;
		var y = 0;
		var rand = parseInt(Math.random() * (x - y + 1) + y);
		$('#new_category').append("<button type='button' id='show_category" + rand  + "' class='btn category btn-primary  p-2 m-1'>" +
		$('#input_category').val() + "<a><i class='fa fa-times-rectangle' id='close_category" + rand  + "'></i></a></button>");
		$("body").on("click", ("#close_category"+rand), function() {
			  $('#show_category'+rand).remove();
		  });
	  }
	});
	$('#input_catelog').keyup(function(event){
		if(event.keyCode ==13){
		var x = 1000;
		var y = 0;
		var rand = parseInt(Math.random() * (x - y + 1) + y);
		$('#new_catelog').append("<button type='button' id='show_catalog" + rand  + "' class='btn btn-primary catalog  p-2 m-1'>" +
		$('#input_catelog').val() + "<a><i class='fa fa-times-rectangle' id='close_catelog" + rand  + "'></i></a></button>");
		$('#content').append("<div class='ibox' id='show_content" + rand  + "'><div class='ibox-title'><h5>" +
		$('#input_catelog').val() + "</h5></div><div class='ibox-content'><textarea class='form-control'></textarea></div></div><div class='clearfix'></div>");
		$("body").on("click", ("#close_catelog"+rand), function() {
			  $('#show_catalog'+rand).remove();
			  $('#show_content'+rand).remove();
		  });
	  }
	});
	
	$("#go_index").on("click", function () {
		window.location.href = "index.php?a=home&c=home&m=index";
	});
	
	$("#cancel").on("click", function () {
		window.location.href = "index.php?a=home&c=person&m=index";
	});
	
	tinymce.init({
		selector: '#edit_content',
		menubar: false,
		branding: false,
		plugins: [
		'advlist autolink lists link image charmap print preview anchor textcolor',
		'searchreplace visualblocks code fullscreen',
		'insertdatetime media table paste code help wordcount'
		],
	toolbar: 'undo redo | fontsizeselect | forecolor  permanentpen formatpainter |link image media  table| alignleft aligncenter alignright alignjustify | outdent indent |code fullscreen',
    });
	
	
	$("#upload").on("click", function () {


		var category_text = new Array();
		$(".category").each(function(){
			category_text.push($(this).text());
		});
		var catalog_text =new Array();
		$(".catalog").each(function(){
			catalog_text.push($(this).text());
		});
		var content_text = new Array();
		$("div>textarea").each(function(){			
			content_text.push($(this).val());
		});		
		$.ajax({
				type : 'POST',
				url : 'index.php?a=home&c=person&m=edit_insert',
				data :  {	
							id:$("input[name='title']").attr("id") ,
							title:$("input[name ='title']").val(),
							category:category_text,
							catalog:catalog_text,
							content:content_text
						},
				async : false,		
				success : function (data) {
					if(data ==1)
					{
						window.location.href = "index.php?a=home&c=person&m=index";
					}
					else if (data == 2){
						 swal({
							title: "错误",
							text: "标题不能为空"
						});							 
					}
					else if (data == 3){
						swal({
							title: "错误",
							text: "简介不能为空"
						});							 
					}
					else if (data == 4){
						 swal({
							title: "错误",
							text: "有分类不存在"
						});						 
					}
					else if (data == 5){
						 swal({
							title: "错误",
							text: "分类不能为空"
						});							 
					}
					else if (data == 6){
						 swal({
							title: "错误",
							text: "目录不能为空"
						});							 
					}
					else
					{
						swal({
							title: "错误",
							text: "数据库错误"
						});
					}
					
				}
		});
				
	});
	
	var id = $(".document_id").attr('id');
	if(id != 0)
	{
		$.ajax({
				type : 'POST',
				url : 'index.php?a=home&c=person&m=edit_json',
				data :  {	
							id:id,
						},
				async : false,		
				success : function (data) {
							if(data){
								var data = eval('('+ data +')'); 
								$(".document_id").val(data.title);
								$("#description").val(data.description);								
								for (i = 0; i < data.category.length; i++) { 
									$('#new_category').append("<button type='button' id='show_category" + i  + "' class='btn category btn-primary  p-2 m-1'>" +
									data.category[i] + "<a><i class='fa fa-times-rectangle' id='close_category" + i  + "'></i></a></button>");												
									(function(i) {
										$("#close_category" + i).on("click", function(){
											$('#show_category'+ i).remove();
										});
									})(i);														
								}
								
								for (i = 0; i < data.catalog.length; i++) { 
									$('#new_catelog').append("<button type='button' id='show_catalog" + i  + "' class='btn catalog btn-primary  p-2 m-1'>" +
									data.catalog[i] + "<a><i class='fa fa-times-rectangle' id='close_catelog" + i  + "'></i></a></button>");
									$('#content').append("<div class='ibox' id='show_content" + i  + "'><div class='ibox-title'><h5>" +
									data.catalog[i] + "</h5></div><div class='ibox-content'><textarea class='form-control' id=content"+i+"></textarea></div></div><div class='clearfix'></div>");
									$('#content'+i).val(data.content[i]);
									(function(i) {
										$("#close_catelog" + i).on("click", function(){
											$('#show_catalog'+ i).remove();
											$('#show_content'+ i).remove();
										});
									})(i);	
								$("div>textarea").focus(function(){
									 tinyMCE.activeEditor.setContent($(this).val());			
								});
								}	
							}											
						},
				});

	}
});